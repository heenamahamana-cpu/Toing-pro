# Toing Assistant — safe demo starter

This repository is a mobile-friendly FastAPI order-draft demo.

## Included
- Responsive iPhone-friendly web interface
- Sample product catalogue and cart
- Myself / someone else recipient selector
- Name, phone and address fields
- Server-side price calculation and SQLite order drafts
- `/health` health endpoint
- JSON syntax checker that does not store or return submitted credential values

## Important limitations
This is **not** connected to Toing. It does not sign in to Toing, use OTPs, replay session JSON, submit real orders, generate payment QR codes, or verify payments. Those require authorised Toing APIs and a legitimate payment provider integration. Orders are saved as `unpaid_draft`.

Never commit `.env` files, Telegram bot tokens, OTPs, cookies, or session JSON. If a session token was shared, sign out/revoke that session.

## Run locally
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```
Open `http://127.0.0.1:8000`.

## Deploy to Railway
1. Push this repository to GitHub.
2. In Railway, create a project and deploy from the GitHub repository.
3. Railway detects `railway.json` / `Procfile`.
4. Add `DB_PATH=/app/data/orders.db` in Variables.
5. Add a Railway Volume mounted at `/app/data` so SQLite data persists.
6. Generate a public domain and test `/health`.

No secrets are needed for the demo website. Do not add a bot token until a real Telegram bot integration is implemented and reviewed.
