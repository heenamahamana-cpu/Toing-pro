import os, json, hmac, hashlib, sqlite3, time
from pathlib import Path
from typing import Optional
from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

BASE = Path(__file__).resolve().parent.parent
DB_PATH = os.getenv("DB_PATH", str(BASE / "orders.db"))
app = FastAPI(title="Toing Assistant Demo")
app.mount("/static", StaticFiles(directory=str(BASE / "app" / "static")), name="static")

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    Path(DB_PATH).parent.mkdir(parents=True, exist_ok=True)
    with db() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            customer_name TEXT NOT NULL, phone TEXT NOT NULL,
            address TEXT NOT NULL, recipient_type TEXT NOT NULL,
            items_json TEXT NOT NULL, total REAL NOT NULL,
            status TEXT NOT NULL DEFAULT 'unpaid_draft',
            created_at INTEGER NOT NULL
        )""")

init_db()

CATALOG = [
    {"id": "sample-item", "name": "Sample Item", "price": 99},
    {"id": "sample-bundle", "name": "Sample Bundle", "price": 199}
]

class OrderIn(BaseModel):
    customer_name: str = Field(min_length=2, max_length=80)
    phone: str = Field(min_length=8, max_length=16)
    address: str = Field(min_length=5, max_length=500)
    recipient_type: str = "myself"
    items: list[dict]

@app.get("/", response_class=HTMLResponse)
def home():
    return (BASE / "app" / "static" / "index.html").read_text(encoding="utf-8")

@app.get("/health")
def health():
    return {"ok": True, "service": "toing-assistant-demo"}

@app.get("/api/catalog")
def catalog():
    return CATALOG

@app.post("/api/orders")
def create_order(payload: OrderIn):
    allowed = {x["id"]: x for x in CATALOG}
    normalized, total = [], 0
    for item in payload.items:
        product_id = str(item.get("id", ""))
        qty = int(item.get("qty", 0))
        if product_id not in allowed or qty < 1 or qty > 20:
            raise HTTPException(400, "Invalid cart item")
        product = allowed[product_id]
        normalized.append({"id": product_id, "name": product["name"], "qty": qty, "unit_price": product["price"]})
        total += product["price"] * qty
    if not normalized:
        raise HTTPException(400, "Cart is empty")
    with db() as con:
        cur = con.execute(
            """INSERT INTO orders(customer_name,phone,address,recipient_type,items_json,total,created_at)
               VALUES(?,?,?,?,?,?,?)""",
            (payload.customer_name, payload.phone, payload.address,
             payload.recipient_type, json.dumps(normalized), total, int(time.time()))
        )
        order_id = cur.lastrowid
    # This is deliberately an unpaid draft. No payment is collected or verified here.
    return {"order_id": order_id, "total": total, "status": "unpaid_draft",
            "message": "Order draft created. Payment is not configured."}

@app.post("/telegram/webhook")
async def telegram_webhook(request: Request):
    secret = os.getenv("WEBHOOK_SECRET")
    if secret:
        supplied = request.headers.get("X-Telegram-Bot-Api-Secret-Token", "")
        if not hmac.compare_digest(supplied, secret):
            raise HTTPException(403, "Invalid webhook secret")
    update = await request.json()
    # Telegram integration is intentionally a safe starter placeholder.
    # Configure BOT_TOKEN and implement authorised bot commands before going live.
    return {"ok": True, "received_update": bool(update)}

@app.post("/api/json-check")
async def json_check(request: Request):
    # JSON is processed only in memory. Never persist or return credential values.
    body = await request.json()
    raw = body.get("json_text", "")
    if not isinstance(raw, str) or len(raw) > 100_000:
        raise HTTPException(400, "Invalid JSON input")
    try:
        parsed = json.loads(raw)
    except Exception:
        return {"valid": False, "message": "JSON syntax is invalid"}
    if not isinstance(parsed, dict):
        return {"valid": False, "message": "Expected a JSON object"}
    keys = ["token", "tid", "sid", "deviceId"]
    present = [k for k in keys if k in parsed]
    return {"valid": True, "message": "Valid JSON object",
            "credential_like_fields_present": present,
            "warning": "This checker does not log in to Toing or upload/store the JSON. Treat session tokens as passwords."}
